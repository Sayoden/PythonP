import numpy as np

def symetrique(A):
    hauteur = len(A)
    largeur = len(A[0])

    if hauteur == largeur :
        for i in range(hauteur):
            for j in range(largeur):
                if A[i][j] != A[j][i] :
                    return False
        return True
    else:
        return False

def antiSymetrique(A):
    hauteur = len(A)
    largeur = len(A[0])
    Resultat = True

    if hauteur == largeur :
        for i in range(hauteur):
            for j in range(largeur):
                if A[i][j] == -A[j][i] :
                    Resultat = True
                else:
                    Resultat = False
        return Resultat


def decompose(A):
    hauteur = len(A)
    largeur = len(A[0])

    #Transposition...
    A=array(A)
    t= A.shape
    B = eye(t[1],t[0])
    for i in range(0,t[0]):
        for j in range(0,t[1]):
                B[j,i]=A[i,j]
    At = B


    Res = eye(hauteur,largeur)
    Res1 = eye(hauteur,largeur)
    
    Res = (dot((1/2),(A+At)))
    Res1 = (dot((1/2),(A-At)))

    if symetrique(Res):
        print("La partie symétrique: ",Res)
    if symetrique(Res1):
        print("La partie symétrique: ",Res1)

    if antiSymetrique(Res):
         print("La partie Antisymétrique: ",Res)
    if antiSymetrique(Res1):
        print("La partie Antisymétrique: ",Res1)


def triangsup(A):
    if len(A) == len(A[0]):
        res = create(len(A), len(A[0]))
        for i in range(len(A)):
            for j in range(i, len(A[0])):
                res[i][j] = A[i][j]
        return res

def triangulairesup(A):
    if len(A) == len(A[0]):
        for i in range(len(A)):
            for j in range(0, i):
                print(A[i][j], i, j)
                if A[i][j] != 0:
                    return triangsup(A) 
        return True


def trianginf(A):
    if len(A) == len(A[0]):
        res = create(len(A),len(A[0]))
        for i in range(len(A)):
            for j in range(0, i+1):
                res[i][j] = A[i][j]
        return res

#Je n'ai pas réussi à faire le triangulaireInf

def decomposediag(A):
    diag = diagonale(A)
    sup = triangsup(A)
    inf = trianginf(A)
    return (diag, soustraction(sup, diag), soustraction(inf, diag))