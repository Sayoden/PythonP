import numpy as np

def minimum(matrice):
    hauteur = len(matrice)
    largeur = len(matrice[0])


    minLigne = []
    coord = []

    for ligne in matrice:
        minLigne = ligne[0]
        for x in ligne:
            if x < minLigne :
                minLigne.append(x)
    realMin = minLigne[0]

    for z in minLigne :
        if z < realMin :
            realMin = z


    for i in range(largeur):
        for j in range(hauteur):
            if matrice[i][j] == realMin:
                #Ajout des coordonnées dans la liste
                coord.append([i, j])

    return "{} , {}".format(realMin, coord)


print(minimum([[-10,-10,4],[12,16,-8],[12,10,-2]]))